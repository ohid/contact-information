@extends('layouts.app')

@section('title', 'All Friends | Contact Information')

@section('content')
<div class="container">
    <div class="row">
        <div class="col m8 offset-m2">
        	<div class="table-responsive">
	        	<table class="table">
					
					<tr>
						<th>Name</th>
						<th class="hidden">Email</th>
						<th>Pro Pic</th>
						<th class="hidden">Mobile No.</th>
						<th>Action</th>
					</tr>
	        		@if( count( $contacts ) > 0 )
	        			@foreach( $contacts as $contact )
			        		<tr>
								<td> {{ $contact->user->name }} </td>
								<td class="hidden"> {{ $contact->user->email }} </td>
								<td > <img src="{{ $contact->user->getImage(40) }}" alt=""> </td>
								<td class="hidden"> {{ $contact->phone }} </td>
								<td> <a href="{{ route('single.friend', $contact->user->id) }}" class="waves-effect waves-light btn"> View profile </a> </td>
			        		</tr>
	        			@endforeach
	        		@else 
	        			<tr>
	        				<td colspan="5" align="center">No friends information</td>
	        			</tr>
	        		@endif 

	        	</table>
        	</div>

        	{{ $contacts->render() }}
        </div>
    </div>
</div>
@endsection
