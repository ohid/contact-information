<?php $__env->startSection('title', 'Edit your Information | Contact Information'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col m8 offset-m2">
            
            <div class="form-wrapper">
                <h3>Your Information</h3>

                <?php echo $__env->make('partials.site.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo e(Form::model($contact, [
					'route'	=> ['post.edit.contact.info', $contact->id],
					'method'	=> 'post',
					'role'	=> 'form',
               	])); ?>

                    <?php echo e(csrf_field()); ?>


                    <div class="input-field ">
						<?php echo e(Form::textarea('about', null, ['placeholder' => 'About me', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('about')); ?>


						<?php if($errors->has('about')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('about')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('phone', null, ['placeholder' => 'Phone', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('phone')); ?>


						<?php if($errors->has('phone')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('phone')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('telephone', null, ['placeholder' => 'Telephone', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('telephone')); ?>


						<?php if($errors->has('telephone')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('telephone')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('blood_group', null, ['placeholder' => 'Blood Group', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('blood_group')); ?>


						<?php if($errors->has('blood_group')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('blood_group')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('current_address', null, ['placeholder' => 'Current address', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('current_address')); ?>


						<?php if($errors->has('current_address')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('current_address')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('permanent_address', null, ['placeholder' => 'Permanent address', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('permanent_address')); ?>


						<?php if($errors->has('permanent_address')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('permanent_address')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('batch', null, ['placeholder' => 'Batch', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('batch')); ?>


						<?php if($errors->has('batch')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('batch')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('shift', null, ['placeholder' => 'Shift', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('shift')); ?>


						<?php if($errors->has('shift')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('shift')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('department', null, ['placeholder' => 'Department', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('department')); ?>


						<?php if($errors->has('department')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('department')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::text('current_study_inst', null, ['placeholder' => 'Current study inst', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('current_study_inst')); ?>


						<?php if($errors->has('current_study_inst')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('current_study_inst')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::textarea('hobby', null, ['placeholder' => 'Hobby', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('hobby')); ?>


						<?php if($errors->has('hobby')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('hobby')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>

                    <div class="input-field ">
						<?php echo e(Form::textarea('aim_in_life', null, ['placeholder' => 'Aim in life', 'class' => 'validate'])); ?>

						<?php echo e(Form::label('aim_in_life')); ?>


						<?php if($errors->has('aim_in_life')): ?>
						<span class="help-block">
						    <strong><?php echo e($errors->first('aim_in_life')); ?></strong>
						</span>
						<?php endif; ?>
                    </div>


                    <button type="submit" class="btn blue darken-1">
                        Update
                    </button>

                </form>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>