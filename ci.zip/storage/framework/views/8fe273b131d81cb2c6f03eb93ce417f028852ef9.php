<?php $__env->startSection('title', 'All Friends | Contact Information'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col m8 offset-m2">
        	<div class="table-responsive">
	        	<table class="table">
					
					<tr>
						<th>Name</th>
						<th class="hidden">Email</th>
						<th>Pro Pic</th>
						<th class="hidden">Mobile No.</th>
						<th>Action</th>
					</tr>
	        		<?php if( count( $contacts ) > 0 ): ?>
	        			<?php foreach( $contacts as $contact ): ?>
			        		<tr>
								<td> <?php echo e($contact->user->name); ?> </td>
								<td class="hidden"> <?php echo e($contact->user->email); ?> </td>
								<td > <img src="<?php echo e($contact->user->getImage(40)); ?>" alt=""> </td>
								<td class="hidden"> <?php echo e($contact->phone); ?> </td>
								<td> <a href="<?php echo e(route('single.friend', $contact->user->id)); ?>" class="waves-effect waves-light btn"> View profile </a> </td>
			        		</tr>
	        			<?php endforeach; ?>
	        		<?php else: ?> 
	        			<tr>
	        				<td colspan="5" align="center">No friends information</td>
	        			</tr>
	        		<?php endif; ?> 

	        	</table>
        	</div>

        	<?php echo e($contacts->render()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>