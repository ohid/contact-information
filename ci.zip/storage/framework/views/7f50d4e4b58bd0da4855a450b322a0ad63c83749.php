<?php $__env->startSection('title', $user->name . ' | Contact Information'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row profile">
        <div class="col m8 offset-m2">
			<div class="row">
				<div class="col m6 s12">
					<div class="profile-left">
						<img src="<?php echo e($user->getImage(400)); ?>" alt="">
						<h2> <?php echo e($user->name); ?> 
							<?php if( $user->nickname ): ?>
								<span> (<?php echo e($user->nickname); ?>) </span>
							<?php endif; ?>
						</h2>
						<table class="table">
							<tr>
								<th> Email: </th>
								<td> <?php echo e($user->email); ?> </td>
							</tr>

							<?php if( $user->contact ): ?>
								<tr>
									<th> Mobile No: </th>
									<td> <?php echo e($user->contact->phone); ?> </td>
								</tr>

								<?php if( $user->contact->telephone ): ?>
									<tr>
										<th> Telephone: </th>
										<td> <?php echo e($user->contact->telephone); ?> </td>
									</tr>
								<?php endif; ?>

								<tr>
									<th> Shift: </th>
									<td> <?php echo e($user->contact->shift); ?> </td>
								</tr>

								<tr>
									<th> Department: </th>
									<td> <?php echo e($user->contact->department); ?> </td>
								</tr>

								<tr>
									<th> Blood Group: </th>
									<td> <?php echo e($user->contact->blood_group); ?> </td>
								</tr>
							<?php endif; ?>

						</table>
					</div>
				</div>
				<div class="col m6 s12">
					<div class="list-info">

						<?php if( $user->contact ): ?>
							<div class="s-list">
								<div class="title">
									<b> <i>About <?php echo e($user->name); ?>, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->about); ?>

								</div>
							</div>

							<div class="s-list">
								<div class="title">
									<b> <i> Hobby, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->hobby); ?>

								</div>
							</div>

							<div class="s-list">
								<div class="title">
									<b> <i>Aim in life, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->aim_in_life); ?>

								</div>
							</div>
							
							<div class="s-list">
								<div class="title">
									<b> <i>Current Study Institution, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->current_study_inst); ?>

								</div>
							</div>
							
							<div class="s-list">
								<div class="title">
									<b> <i>Current Address, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->current_address); ?>

								</div>
							</div>
							
							<div class="s-list">
								<div class="title">
									<b> <i>Permanent Address, </i> </b>
								</div>
								<div class="content"> <?php echo e($user->contact->permanent_address); ?>

								</div>
							</div>
						<?php endif; ?>



					</div>
				</div>
			</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>