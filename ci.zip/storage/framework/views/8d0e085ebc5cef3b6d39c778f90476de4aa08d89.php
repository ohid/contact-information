<?php $__env->startSection('title', 'Register | Support Pro'); ?>


<?php $__env->startSection('content'); ?>
<p class="title">Register now</p>
<div class="the-form register-form">

    <?php echo e(Form::open(['url' => 'register', 'method' => 'post'])); ?>

        <div class="form-group">
            <?php echo e(Form::text('first_name', null, ['placeholder' => 'First name', 'class' => 'form-control'])); ?>


            <?php if( $errors->any() ): ?> 
                <span class="help-block"> <?php echo e($errors->first('first_name')); ?> </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <?php echo e(Form::text('last_name', null, ['placeholder' => 'Last name', 'class' => 'form-control'])); ?>


            <?php if( $errors->any() ): ?> 
                <span class="help-block"> <?php echo e($errors->first('last_name')); ?> </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <?php echo e(Form::email('email', null, ['placeholder' => 'Email Address', 'class' => 'form-control'])); ?>


            <?php if( $errors->any() ): ?> 
                <span class="help-block"> <?php echo e($errors->first('email')); ?> </span>
            <?php endif; ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::password('password', ['placeholder' => 'Password', 'class' => 'form-control'])); ?>


            <?php if( $errors->any() ): ?> 
                <span class="help-block"> <?php echo e($errors->first('password')); ?> </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <?php echo e(Form::password('password_confirmation', ['placeholder' => 'Confirm Password', 'class' => 'form-control'])); ?>

            <span class="help-block"></span>

            <?php if( $errors->any() ): ?> 
                <span class="help-block"> <?php echo e($errors->first('password_confirmation')); ?> </span>
            <?php endif; ?>
        </div>

        <?php echo e(Form::submit('register', ['class' => 'btn btn-success'])); ?>


        <div class="help-links">
            <p><a href="login">Already a user? Login here</a></p>
        </div>
        
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>