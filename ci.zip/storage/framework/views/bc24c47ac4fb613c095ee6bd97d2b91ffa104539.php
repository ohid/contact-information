<?php $__env->startSection('title', 'Settings | Contact Info'); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col m8 offset-m2">

            <div class="form-wrapper ">
                <h3>Your Profile Settings</h3>
                
                <?php echo $__env->make('partials.site.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo e(Form::model($user, [
					'route'	=> 'post.profile.settings',
					'method'	=> 'POST',
                    'enctype' => 'multipart/form-data'
               	])); ?>


                    <div class="input-field ">
                    	<?php echo e(Form::text('name', null, ['class' => 'validate'])); ?>

                    	<?php echo e(Form::label('name', 'Your name')); ?>


                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="input-field ">
                    	<?php echo e(Form::text('nickname', null, ['class' => 'validate'])); ?>

                    	<?php echo e(Form::label('nickname', 'Your Nickname')); ?>


                        <?php if($errors->has('nickname')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('nickname')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>


                    <div class="input-field ">
                    	<?php echo e(Form::text('email', null, ['class' => 'validate'])); ?>

                    	<?php echo e(Form::label('email', 'Your Email')); ?>


                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="input-field ">
                      <input placeholder="Your Password" id="password"  name="password" type="password" class="validate ">
                      <label for="password">Password</label>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>


                    <div class="input-field ">
						<div class="file-field input-field">
							<div class="btn">
								<span>Profile Picture</span>
								<input type="file" name="file">
							</div>
							<div class="file-path-wrapper">
								<input class="file-path validate" type="text">
							</div>
						</div>           


                        <?php if($errors->has('file')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('file')); ?></strong>
                            </span>
                        <?php endif; ?>  	
                    </div>

                    <button type="submit" class="btn blue darken-1">
                        Save
                    </button>

                </form>
            </div>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>