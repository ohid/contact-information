<?php if( Session::has('message') ): ?>
	<div class="alert">
		<?php echo e(Session::get('message')); ?>

	</div>
<?php endif; ?>